<html>

<head>
    <link rel="stylesheet" href="home.css">
    <title>PHP Test</title>
</head>

<body>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "waterfiend";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if (isset($_REQUEST['Submit'])) {
        $pname = $_POST['pname'];
        $pcode = $_POST['pcode'];
        $pprice = $_POST['pprice'];
        $pkek = $_POST['pkek'];

        // checking empty fields
        if (empty($pname) || empty($pcode) || empty($pprice) || empty($pkek)) {
            if (empty($pname)) {
                echo '<font color="#ff3333">Contact Name field is empty.</font><br>';
            }
            if (empty($pcode)) {
                echo '<font color="#ff3333">Profession field is empty.</font><br>';
            }
            if (empty($pprice)) {
                echo '<font color="#ff3333">Tel. Phone field is empty.</font><br>';
            }
            if (empty($pkek)) {
                echo '<font color="#ff3333">Mobile number field is empty.</font><br>';
            }
            //link to the previous page
            echo '<br><a href="javascript:self.history.back();">Go Back</a>';
        } else {
            // if all the fields are filled (not empty)             
            //insert data to database
            $result = mysqli_query($conn, "INSERT INTO table1(contact_name,contact_profession,contact_tel_number, contact_mobile_number) VALUES('$pname','$pcode','$pprice', '$pkek')");

            //display success message
            echo '<font color="#7fff7f">Data added successfully.</font>';
        }
    }
    ?>
    <?php echo '<p>Welcome!</p>'; ?>
    <title>Insert Data and Display in Table </title>


    <form action="" method="post" name="form1">
        <table width="25%" border="0">
            <tbody>
                <tr>
                    <td>Product Name</td>
                    <td><input type="text" name="pname"></td>
                </tr>
                <tr>
                    <td>Product Code</td>
                    <td><input type="text" name="pcode"></td>
                </tr>
                <tr>
                    <td>Product Price </td>
                    <td><input type="text" name="pprice"></td>
                </tr>
                <tr>
                    <td>Product Kek </td>
                    <td><input type="text" name="pkek"></td>
                </tr>
            </tbody>
        </table>
        <input type="submit" name="Submit" value="Add"/>
        <input type="submit" name="update" value="Update"/>
        <input type="submit" name="delete" value="Delete"/>
    </form>

    <html>

    <head>
        <title>Display data in table with edit button </title>
    </head>

    <body>

        <table width='50%' height='15%' border='0'>

            <tr bgcolor='yellow'>
                <td>Contact Name</td>
                <td>Contact Profession</td>
                <td>Telephone Number</td>
                <td>Mobile Number</td>
            </tr>
            <?php

            $res = mysqli_query($conn, "SELECT * FROM table1");
            while ($kek = mysqli_fetch_array($res)) {
                echo "<tr>";
                echo "<td bgcolor=''>" . $kek['contact_name'] . "</td>";
                echo "<td>" . $kek['contact_profession'] . "</td>";
                echo "<td>" . $kek['contact_tel_number'] . "</td>";
                echo "<td>" . $kek['contact_mobile_number'] . "</td>";
            }
            ?>
        </table>
        <?php
        //echo var_dump($_REQUEST);
        //echo var_dump($_POST);
        if (isset($_REQUEST['update'])) {
            # echo var_dump($_REQUEST);
            $id = mysqli_real_escape_string($conn, $_REQUEST['pname']);
            $name = mysqli_real_escape_string($conn, $_REQUEST['pcode']);
            $age = mysqli_real_escape_string($conn, $_REQUEST['pprice']);
            $email = mysqli_real_escape_string($conn, $_REQUEST['pkek']);
            if (empty($name) || empty($age) || empty($email)) {
                if (empty($name)) {
                    echo '<font color="#ff3333">Name field is empty.</font><br>';
                }
                if (empty($age)) {
                    echo '<font color="#ff3333">Age field is empty.</font><br>';
                }
                if (empty($email)) {
                    echo '<font color="#ff3333">Email field is empty.</font><br>';
                }
            } else {
                $result = mysqli_query($conn, "UPDATE table1 SET contact_profession='$name',contact_tel_number='$age',contact_mobile_number='$email' WHERE contact_name='$id'");
                header("Location: index.php");
            }
        }
        if (isset($_REQUEST['delete'])) {
            $id = mysqli_real_escape_string($conn, $_REQUEST['pname']);
            $result = mysqli_query($conn, "DELETE FROM table1 WHERE contact_name='$id'");
        }
        mysqli_close($conn);
        ?>
    </body>

    </html>
</body>
<?php

?>

</html>