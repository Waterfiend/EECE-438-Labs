const express = require('express');
const bodyParser = require('body-parser')
const cors = require('cors')
const app = express();
const mysql = require('mysql2');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cruddatabase',
});

app.use(cors());
app.use(express.json())
app.use(bodyParser.urlencoded({
    extended: true
}));

app.get("/api/get", (req, res) => {
    const query = "SELECT * FROM movie_reviews order by name_movie";
    db.query(query, (err, result) => {
        res.send(result);
        console.log(result);
    });
});

app.post('/api/insert', (req, res) => {

    const name_movie = req.body.movie_name;
    const review_movie = req.body.revMovie;

    const query2 =
        "INSERT INTO movie_reviews (name_movie, review_movie) VALUES (?,?)";
    db.query(query2, [name_movie, review_movie], (err, result) => {
        console.log(result);
    });
});

app.delete('/api/delete/:movie_name', (req, res) => {
    const movie_name = req.params.movie_name;
    const delete_query = "DELETE FROM movie_reviews WHERE movie_name = ?";

    db.query(delete_query, movie_name, (err, result) => {
        if (err) console.log(err);
    });
});

app.find_movie('/api/find_movie/:movie_name', (req, res) => {
    const mmovie_name = req.params.movie_name;
    const sqlSelect = "SELECT FROM movie_reviews WHERE movie_name = ?";
    db.query(sqlSelect, mmovie_name, (err, result) => {
        if (err) console.log(err);
        console.log(result);
    });
});

app.put("/api/update", (req, res) => {
    const nameof_movie = req.body.movie_name;
    const rev_movie = req.body.revMovie;
    const sqlUpdate = "UPDATE movie_reviews SET movieReview = ? WHERE movie_name = ?";

    db.query(sqlUpdate, [rev_movie, nameof_movie], (err, result) => {
        if (err) console.log(err);
    });
});

app.listen(3001, () => {
    console.log("Listening on Port 3001!");
});